/**
 * @file student.h
 * @brief Contains the typedef struct for the student class and various course methods
 */

/**
 * @typedef Student 
 * @brief This is the type definition for the student class that will represent courses
 * @struct _student 
 * @brief This is the structure definition for the student that contains all the parameters and properties of this structure
 */
typedef struct _student 
{ 
  char first_name[50]; /**< First name of student */
  char last_name[50]; /**< Last name of student */
  char id[11];  /**< Student ID of student */
  double *grades; /**< Array of grades of the student */
  int num_grades; /**< Number of grades student has */
} Student;

/** @brief Adds a grade(number) to the student
 * 
 * @param student The student to which the grade is added to
 * @param grade The number which represents the grade
 */
void add_grade(Student *student, double grade);

/** @brief Calculates the average of all the students grades
 * 
 * @param student The student to which the average is calculated for
 */
double average(Student *student);

/** @brief Prints information about the student
 * 
 * @param student The student to which the information is printed about
 */
void print_student(Student *student);

/** @brief Creates and returns the random student
 * 
 * @param grades A starting grade given to the random student
 */
Student* generate_random_student(int grades); 
