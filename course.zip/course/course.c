/**
 * @file course.c
 * @brief Contains the definitions for the methods of the course typedef
 * @include student.h
 * @include stdbool.h
 * @include stdio.h
 */

#include "course.h"
#include <stdlib.h>
#include <stdio.h>

/** @brief The enroll_student method will add a student to the course
 * 
 * @param course The course to which the student is added to
 * @param student The student which is added to the course
 * @return Nothing
 */
void enroll_student(Course *course, Student *student)
{
  course->total_students++;
  if (course->total_students == 1) // Checks if there's only 1 student
  {
    course->students = calloc(1, sizeof(Student)); // Creates space for the 1 student
  }
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); // Reallocates space for the new student to be added to the course
  }
  course->students[course->total_students - 1] = *student;
}

/** @brief Will print information about the course
 * 
 * @param course The course to which the information is printed about
 * @return Nothing
 */
void print_course(Course* course)
{
  printf("Name: %s\n", course->name); // Prints out information about the course
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);  // Prints out information about the students
}

/** @brief Will return the top student in a particular course
 * 
 * @param course The course to which the top student is search in
 * @return Student with highest average
 */
Student* top_student(Course* course)
{
  if (course->total_students == 0) return NULL; // Checks if the course is empty
 
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 
  for (int i = 1; i < course->total_students; i++) // Iterates through ever student
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) // Checks if the student is greater than the max currently stored
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}


/** @brief Will return array of students passing in the course
 * 
 * @param course The course which the students are checked for passing
 * @param total_passing Takes the number of students that are currently passing in the course
 * @return Array of passing students
 */
Student *passing(Course* course, int *total_passing)
{
  int count = 0;
  Student *passing = NULL;
  
  for (int i = 0; i < course->total_students; i++)  // Iterates through all the students
    if (average(&course->students[i]) >= 50) count++; // If the student is passing, increase the num by 1
  
  passing = calloc(count, sizeof(Student)); // Create memory for all the passing students

  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i]; // Add the passing students to the array
      j++; 
    }
  }

  *total_passing = count; // Update the passing count

  return passing; // Return all the passing students
}