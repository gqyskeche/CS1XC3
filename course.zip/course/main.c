/**
 * @file main.c
 * @brief Main file of execution for the course and student programs
 * @include string.h
 * @include stdbool.h
 * @include stdio.h
 * @include time.h
 * @include course.h
 */

#include <stdlib.h> 
#include <stdio.h>
#include <string.h>
#include "time.h"
#include "course.h"

/** @brief This is the main method of the file which will automatically be executed 
 */
int main()
{
  srand((unsigned) time(NULL));

  Course *MATH101 = calloc(1, sizeof(Course));    // Creates MATH101 course
  strcpy(MATH101->name, "Basics of Mathematics"); // Adds the properties of the course
  strcpy(MATH101->code, "MATH 101");

  for (int i = 0; i < 20; i++) 
    enroll_student(MATH101, generate_random_student(8));  // Enrolls students into MATH101
  
  print_course(MATH101);

  Student *student;                             // Instatiate a student to contain the top student in the course and output
  student = top_student(MATH101);
  printf("\n\nTop student: \n\n");
  print_student(student);

  int total_passing;    
  Student *passing_students = passing(MATH101, &total_passing); // Finds and stores all passing students
  printf("\nTotal passing: %d\n", total_passing);
  printf("\nPassing students:\n\n");
  for (int i = 0; i < total_passing; i++) print_student(&passing_students[i]); // Print the passing students
  
  return 0;
}