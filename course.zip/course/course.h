/**
 * @file course.h
 * @brief Contains the typedef struct for the course class and various course methods
 * @include student.h
 * @include stdbool.h
 */

#include "student.h"
#include <stdbool.h>

/**
 * @typedef Course 
 * @brief This is the type definition for the course class that will represent courses
 * @struct _course 
 * @brief This is the structure definition for the course that contains all the parameters and properties of this structure
 */

typedef struct _course 
{
  char name[100]; /**< Name of course */
  char code[10];/**< Course code */
  Student *students;/**< Students enrolled in the course */
  int total_students;/**< Number of students in the course */
} Course;

/** @brief The enroll_student method will add a student to the course
 * 
 * @param course The course to which the student is added to
 * @param student The student which is added to the course
 */

void enroll_student(Course *course, Student *student);

/** @brief Will print information about the course
 * 
 * @param course The course to which the information is printed about
 */
void print_course(Course *course);

/** @brief Will return the top student in a particular course
 * 
 * @param course The course to which the top student is search in
 */
Student *top_student(Course* course);

/** @brief Will return array of students passing in the course
 * 
 * @param course The course which the students are checked for passing
 * @param total_passing Takes the number of students that are currently passing in the course
 */
Student *passing(Course* course, int *total_passing);
