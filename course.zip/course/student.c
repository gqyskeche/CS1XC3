/**
 * @file student.c
 * @brief Contains the definitions for the methods of the student typedef
 * @include student.h
 * @include string.h
 * @include stdio.h
 * @include stdlib.h
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/** @brief Adds a grade(number) to the student
 * 
 * @param student The student to which the grade is added to
 * @param grade The number which represents the grade
 * @return Nothing
 */
void add_grade(Student* student, double grade)
{
  student->num_grades++;
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double)); // If this is the only grade for the student, create memory to store it
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades); // Adds memory to add another grade to the student
  }
  student->grades[student->num_grades - 1] = grade;
}

/** @brief Calculates the average of all the students grades
 * 
 * @param student The student to which the average is calculated for
 * @return Average of student
 */
double average(Student* student)
{
  if (student->num_grades == 0) return 0;

  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i]; // Iterates through all the students grades and sums it
  return total / ((double) student->num_grades);  // Returns the average
}

/** @brief Prints information about the student
 * 
 * @param student The student to which the information is printed about
 * @return Nothing
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name); // Prints student information
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++)  // Prints students grades
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/** @brief Creates and returns the random student
 * 
 * @param grades A starting grade given to the random student
 * @return A randomly generated student
 */
Student* generate_random_student(int grades)
{
  char first_names[][24] = // Pool of first names
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  char last_names[][24] = // Pool of last names
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
 
  Student *new_student = calloc(1, sizeof(Student)); // Initializing student

  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);

  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48); // Creating random student id
  new_student->id[10] = '\0';

  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75))); // Adding their grade
  }

  return new_student;
}