var searchData=
[
  ['code_43',['code',['../struct__course.html#ae86dc46bc4dfe126555e5560860b583f',1,'_course']]]
];
